import numpy as np


def calculate(numbers):
    if len(numbers) != 9:
        raise ValueError("List must contain nine numbers.")

    matrica = np.array(numbers).reshape(3, 3)

    # Calculations
    calculations = {
        'mean': [
            matrica.mean(axis=0).tolist(),  # Mean of columns
            matrica.mean(axis=1).tolist(),  # Mean of rows
            matrica.mean().tolist()  # Mean of all elements (flattened)
        ],
        'variance': [
            matrica.var(axis=0).tolist(),  # Variance of columns
            matrica.var(axis=1).tolist(),  # Variance of rows
            matrica.var().tolist()  # Variance of all elements (flattened)
        ],
        'standard deviation': [
            matrica.std(axis=0).tolist(),  # Standard deviation of columns
            matrica.std(axis=1).tolist(),  # Standard deviation of rows
            matrica.std().tolist()  # Standard deviation of all elements (flattened)
        ],
        'max': [
            matrica.max(axis=0).tolist(),  # Max of columns
            matrica.max(axis=1).tolist(),  # Max of rows
            matrica.max().tolist()  # Max of all elements (flattened)
        ],
        'min': [
            matrica.min(axis=0).tolist(),  # Min of columns
            matrica.min(axis=1).tolist(),  # Min of rows
            matrica.min().tolist()  # Min of all elements (flattened)
        ],
        'sum': [
            matrica.sum(axis=0).tolist(),  # Sum of columns
            matrica.sum(axis=1).tolist(),  # Sum of rows
            matrica.sum().tolist()  # Sum of all elements (flattened)
        ]
    }

    return calculations
