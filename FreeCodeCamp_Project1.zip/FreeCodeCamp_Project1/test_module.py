import unittest
from mean_var_std import calculate

class TestCalculate(unittest.TestCase):

    def test_valid_input(self):
        # Valid input: a list with exactly 9 numbers
        input_data = [0, 1, 2, 3, 4, 5, 6, 7, 8]
        result = calculate(input_data)

        expected_result = {
            'mean': [[3.0, 4.0, 5.0], [1.0, 4.0, 7.0], 4.0],
            'variance': [[6.0, 6.0, 6.0], [0.6666666666666666, 0.6666666666666666, 0.6666666666666666], 6.666666666666667],
            'standard deviation': [[2.449489742783178, 2.449489742783178, 2.449489742783178], [0.816496580927726, 0.816496580927726, 0.816496580927726], 2.581988897471611],
            'max': [[6, 7, 8], [2, 5, 8], 8],
            'min': [[0, 1, 2], [0, 3, 6], 0],
            'sum': [[9, 12, 15], [3, 12, 21], 36]
        }

        self.assertEqual(result, expected_result)

    def test_invalid_input(self):
        # Test with an invalid input (not enough numbers)
        with self.assertRaises(ValueError):
            calculate([1, 2, 3, 4, 5, 6])

        # Test with an invalid input (too many numbers)
        with self.assertRaises(ValueError):
            calculate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])

if __name__ == '__main__':
    unittest.main()
